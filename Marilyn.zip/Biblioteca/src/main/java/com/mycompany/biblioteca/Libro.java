/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

/**
 *
 * @author Marilyn
 */
public class Libro implements Comparable<Libro>, CSVSerializable {
     private static final long serialVersionUID = 1L; 
    private int id;
    private String titulo;
    private String autor;
    private Categoria categoria;

    public Libro(int id, String titulo, String autor, Categoria categoria) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public String getTitulo() {
        return titulo;
    }

    
    
    @Override
    public String toString() {
        return "Libro{" + "id=" + id + ", titulo=" + titulo + ", autor=" + autor + ", categoria=" + categoria + '}';
    }

     
    
    @Override
    public int compareTo(Libro otherLibro) {
        return Integer.compare(id,otherLibro.id);    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + autor;    }
    
    
    


    
}

