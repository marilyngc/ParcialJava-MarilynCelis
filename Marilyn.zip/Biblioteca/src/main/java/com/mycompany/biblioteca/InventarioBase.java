/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.biblioteca;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author Marilyn
 */
public interface InventarioBase<T> extends Iterable<T> {
    
     void agregar(T item);
      
    
    
    T obtenerElementos(int indice);
        
    
 
   void eliminar(int indice);
        
    void paraCadaElemento(Consumer<T> accion); 
    
     
        
     List<T> filtrar(Predicate<? super T> criterio);
}
