/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author Marilyn
 */
public class Inventario<T>  implements InventarioBase<T>, Iterable<T> {
    private List<T> items = new ArrayList<>();

    @Override
    public void agregar(T item) {
 if(item == null){
            throw new IllegalArgumentException("No se debe alamcenar nulos");
            
        }else{
            items.add(item);
        }    }

    @Override
    public T obtenerElementos(int indice) {
 validarIndex(indice);
        return items.get(indice);    }

    
   
    
    @Override
    public void eliminar(int indice) {
   validarIndex(indice);
        items.remove(indice);    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
  List<T> aux = new ArrayList<>();
        for(T item : items){
            if(criterio.test(item)){
                aux.add(item);
            }
        }
        return aux;    }
    
     private void validarIndex(int indice){
        if(indice < 0 || indice >= items.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
            
        }
    }
    
     private Iterator<T> iteratorNatural(){
        System.out.println("adentro");
        List<T> aux = new ArrayList<>(items); // manera de copiar una lista
        aux.sort(null); // ordeno la copia
        
        return aux.iterator();
        
    }

    @Override
    public Iterator<T> iterator() {
  if(!items.isEmpty() && items.get(0) instanceof Comparable ){
            return iteratorNatural();
        }
        return items.iterator();    }

    @Override
    public String toString() {
        return "Inventario{" + "items=" + items + '}';
    }
    
    @Override
    public void paraCadaElemento(Consumer<T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }


  public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }
  
  
   
     
     
     
  public void guardarEnArchivo(String path) throws IOException {
        try (FileOutputStream archivo = new FileOutputStream(path);
             ObjectOutputStream salida = new ObjectOutputStream(archivo)) {
            salida.writeObject(items);  // Serializa la lista de libros
            System.out.println("Inventario guardado en el archivo binario: " + path);
        } catch (IOException e) {
            System.out.println("Error al guardar en el archivo: " + e.getMessage());
        }
    }
 
  

 




}




    
  
    
    
    
    
    
    
    
    


