/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.biblioteca;

import java.util.Iterator;

/**
 *
 * @author Marilyn
 */
public class Biblioteca {

    public static void main(String[] args) {
        InventarioBase<Libro> inventarioLibros = new Inventario<>();

        // Agregar libros
        inventarioLibros.agregar(new Libro(1, "1984", "George Orwell",Categoria.ENTRETENIMIENTO));
        inventarioLibros.agregar(new Libro(2, "El señor de los anillos", "J.R.R.Tolkien", Categoria.LITERATURA));
        inventarioLibros.agregar(new Libro(3, "Cien años de soledad", "GabrielGarcía Márquez", Categoria.LITERATURA));
        inventarioLibros.agregar(new Libro(4, "El origen de las especies", "CharlesDarwin", Categoria.CIENCIA));
        inventarioLibros.agregar(new Libro(5, "La guerra de los mundos", "H.G.Wells", Categoria.ENTRETENIMIENTO));
      

         System.out.println("Inventario de libros:");
        inventarioLibros.paraCadaElemento(libro -> System.out.println(libro));

        // Filtrar libros por autor
        System.out.println("\nLibros de la categoría LITERATURA:");
        inventarioLibros
        .filtrar(libro -> "LITERATURA".equals(libro.getCategoria()))
        .forEach(libro -> System.out.println(libro));

        // Filtrar libros cuyo título contiene "1984"
        System.out.println("\nLibros cuyo título contiene '1984':");
        inventarioLibros
        .filtrar(libro -> libro.getTitulo().contains("1984"))
        .forEach(libro -> System.out.println(libro));

        
         System.out.println("\nLibros ordenados de manera natural (por id):");
        Iterator<Libro> it = inventarioLibros.iterator();
        while (it.hasNext()) {
        System.out.println(it.next());
       
    }

    }}
        

 



      
    

