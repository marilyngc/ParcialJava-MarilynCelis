/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Marilyn
 */
public class Serializadora {
     public static void serializarEmpleados(List<? extends Libro> lista, String path) {
          
        
        try (FileOutputStream archivo = new FileOutputStream(path);
               ObjectOutputStream salida = new ObjectOutputStream(archivo))
               {
           
                   salida.writeObject(lista);
                   
       }catch (IOException ex){
              ex.printStackTrace();
               }
    }
    
    
    public static List<Libro> deserializar(String path){
       List<Libro> toReturn = new ArrayList<>();
       
       try(FileInputStream archivo = new FileInputStream("src/resources/mago.bir");
               ObjectInputStream input = new ObjectInputStream(archivo)){
           
           toReturn =(List<Libro>) input.readObject();
           
           System.out.println("Empleado recuperado");
           System.out.println(toReturn);
           
       }catch (IOException |ClassNotFoundException ex){
              ex.printStackTrace();
               }
       return toReturn;
    }
}
